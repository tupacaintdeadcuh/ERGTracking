ERG OAuth App — FINAL (Discord + Shared Passcode)

Permitted Discord IDs (preloaded):
1398843640662458428, 1418300034893615295, 1245796329540816899, 424699992603623427, 1025796960428503082, 658214593281261569, 747524114377474129, 879802038312108162, 262796944651452416, 747104443472019515, 663990535375159323

Admin passcode (preloaded):
vaisgay

SETUP
1) In server/.env.example fill:
   DISCORD_CLIENT_ID=YOUR_ID
   DISCORD_CLIENT_SECRET=YOUR_SECRET
   DISCORD_CALLBACK_URL=https://YOUR-BACKEND/auth/callback
   SESSION_SECRET=your-very-long-random-secret

   # Preloaded:
   PERMITTED_IDS=1398843640662458428,1418300034893615295,1245796329540816899,424699992603623427,1025796960428503082,658214593281261569,747524114377474129,879802038312108162,262796944651452416,747104443472019515,663990535375159323
   ADMIN_PASSCODE=vaisgay

   WEBHOOK_URL=   # paste Discord Webhook URL here later
   PUBLIC_ORIGIN=https://YOUR-FRONTEND-DOMAIN
   PORT=3000

2) Rename .env.example -> .env

3) Deploy 'server' to Render/Railway:
   npm install
   npm start

4) Create a Discord Webhook (Server Settings → Integrations → Webhooks → New Webhook → Copy URL)
   Paste into WEBHOOK_URL in .env to get real-time messages in your channel.

5) iPhone Add to Home Screen:
   Open site in Safari → Share → Add to Home Screen.
